--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: winelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.winelist (
    wine_id integer NOT NULL,
    title character varying(1024) NOT NULL,
    country character varying(50),
    code character varying(10) NOT NULL,
    quantity integer NOT NULL,
    size integer NOT NULL,
    price integer
);


--
-- Name: winelist_wine_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.winelist_wine_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: winelist_wine_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.winelist_wine_id_seq OWNED BY public.winelist.wine_id;


--
-- Name: winelist wine_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.winelist ALTER COLUMN wine_id SET DEFAULT nextval('public.winelist_wine_id_seq'::regclass);


--
-- Data for Name: winelist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.winelist (wine_id, title, country, code, quantity, size, price) FROM stdin;
20	Quinta dos Avidagos 2011 Avidagos Red (Douro)	Portugal	744041	981	750	15
21	Rainstorm 2013 Pinot Gris (Willamette Valley)	US	2160920	555	500	14
22	St. Julian 2013 Reserve Late Harvest Riesling (Lake Michigan Shore)	US	3503669	168	500	13
23	Tandem 2011 Ars In Vitro Tempranillo-Merlot (Navarra)	Spain	7576093	652	750	15
24	Terre di Giurfo 2013 Belsito Frappato (Vittoria)	Italy	5746027	218	500	16
25	Trimbach 2012 Gewurztraminer (Alsace)	France	4094294	848	750	24
26	Heinz Eifel 2013 Shine Gewürztraminer (Rheinhessen)	Germany	4300156	257	500	12
27	Jean-Baptiste Adam 2012 Les Natures Pinot Gris (Alsace)	France	6597706	213	750	27
28	Kirkland Signature 2011 Mountain Cuvée Cabernet Sauvignon (Napa Valley)	US	2838605	387	750	19
29	Leon Beyer 2012 Gewurztraminer (Alsace)	France	9934185	533	500	30
30	Louis M. Martini 2012 Cabernet Sauvignon (Alexander Valley)	US	7973915	809	500	34
31	Mirassou 2012 Chardonnay (Central Coast)	US	3130426	640	750	12
32	Richard Böcking 2013 Devon Riesling (Mosel)	Germany	3673013	551	500	24
33	Felix Lavaque 2010 Felix Malbec (Cafayate)	Argentina	5486180	448	750	30
34	Gaucho Andino 2011 Winemaker Selection Malbec (Mendoza)	Argentina	8730280	133	500	13
35	Pradorey 2010 Vendimia Seleccionada Finca Valdelayegua Single Vineyard Crianza  (Ribera del Duero)	Spain	4815792	203	750	28
36	Quiévremont 2012 Meritage (Virginia)	US	3434250	949	500	32
37	Quiévremont 2012 Vin de Maison Red (Virginia)	US	2399611	349	750	23
38	Acrobat 2013 Pinot Noir (Oregon)	US	2568721	706	500	20
39	Baglio di Pianetto 2007 Ficiligno White (Sicilia)	Italy	9254318	222	500	19
40	Bianchi 2011 Signature Selection Merlot (Paso Robles)	US	1084886	291	750	22
41	Castello di Amorosa 2011 King Ridge Vineyard Pinot Noir (Sonoma Coast)	US	4115971	853	500	69
42	Stemmari 2013 Dalila White (Terre Siciliane)	Italy	2786741	614	750	13
43	Terre di Giurfo 2011 Mascaria Barricato  (Cerasuolo di Vittoria)	Italy	7572928	245	500	17
44	Clarksburg Wine Company 2010 Chenin Blanc (Clarksburg)	US	1734129	932	750	16
45	Envolve 2010 Puma Springs Vineyard Red (Dry Creek Valley)	US	9502961	161	750	50
46	Envolve 2011 Sauvignon Blanc (Sonoma Valley)	US	5067454	236	750	20
47	Erath 2010 Hyland Pinot Noir (McMinnville)	US	7474181	684	500	50
48	Estampa 2011 Estate Viognier-Chardonnay (Colchagua Valley)	Chile	3996868	204	500	15
49	Feudi del Pisciotto 2010 Missoni Cabernet Sauvignon (Sicilia)	Italy	1180336	237	750	21
50	Feudi di San Marzano 2011 I Tratturi Primitivo (Puglia)	Italy	4971699	23	500	11
51	Feudo Montoni 2011 Catarratto (Sicilia)	Italy	3696036	630	500	17
52	Hawkins Cellars 2009 Pinot Noir (Willamette Valley)	US	3341915	33	500	22
53	Henry Fessy 2012 Nouveau  (Beaujolais)	France	6618433	742	750	9
54	Robert Hall 2011 Sauvignon Blanc (Paso Robles)	US	3711608	872	500	14
55	Sundance 2011 Merlot (Maule Valley)	Chile	7792441	681	500	9
56	Tarara 2010 #SocialSecret Red (Virginia)	US	8859590	179	500	40
57	The White Knight 2011 Riesling (Lake County)	US	9067210	4	500	13
58	Trump 2011 Sauvignon Blanc (Monticello)	US	6556538	628	500	16
59	Vignerons de Bel Air 2011 Eté Indien  (Brouilly)	France	5011518	152	500	14
60	Casa Silva 2008 Gran Reserva Petit Verdot (Colchagua Valley)	Chile	724810	988	750	22
61	Cantine di Dolianova 2010 Dolia  (Monica di Sardegna)	Italy	43199	291	750	14
62	RustRidge 2010 Estate Bottled Chardonnay (Napa Valley)	US	4611332	646	750	30
63	Souverain 2010 Chardonnay (North Coast)	US	7613212	879	750	14
64	Tres Palacios 2011 Reserve Pinot Noir (Maipo Valley)	Chile	8170192	880	750	13
65	Mellisoni 2014 Malbec (Columbia Valley (WA))	US	7697849	999	750	55
66	Okapi 2013 Estate Cabernet Sauvignon (Napa Valley)	US	2695096	602	500	100
67	Podere dal Nespoli 2015 Prugneto Sangiovese (Romagna)	Italy	5543481	216	500	17
68	Ram 2014 Alder Ridge Vineyard Cabernet Franc (Columbia Valley (WA))	US	1977630	45	500	25
69	Roland Champion NV Brut Rosé  (Champagne)	France	2442964	218	500	58
70	Sevtap 2015 Golden Horn Sauvignon Blanc (Santa Ynez Valley)	US	3189211	563	750	26
71	Simonnet-Febvre 2015  Chablis	France	9999112	58	750	24
72	Vignerons des Terres Secrètes 2015  Mâcon-Milly Lamartine	France	659662	110	750	15
73	Basel Cellars 2013 Inspired Red (Columbia Valley (WA))	US	4247191	171	500	46
74	Cocobon 2014 Red (California)	US	5856380	356	750	12
75	Collet NV Brut Rosé  (Champagne)	France	5235144	149	500	55
76	Drumheller 2014 Chardonnay (Columbia Valley (WA))	US	8938119	278	750	12
77	Eco Terreno 2013 Old Vine Cabernet Sauvignon (Alexander Valley)	US	5850312	677	500	40
78	Grifalco 2013 Daginestra  (Aglianico del Vulture)	Italy	6547864	893	750	32
79	Hindsight 2013 Bella Vetta Vineyard Cabernet Sauvignon (Howell Mountain)	US	9008025	474	500	75
80	Hindsight 2012 Estate Grown Petite Sirah (Calistoga)	US	1330615	111	750	55
81	Mulvane Wine Co. 2013 The Cypher Red (Napa Valley)	US	6020434	401	500	75
82	Schmitt Söhne 2015 Riesling (Rheinhessen)	Germany	8763401	662	500	9
83	Yalumba 2016 Made With Organic Grapes Chardonnay (South Australia)	Australia	1002329	913	750	18
84	Aresti 2014 Special Release Reserva Carmenère (Rapel Valley)	Chile	6280943	713	500	12
85	Spyro 2014 Albariño (Rías Baixas)	Spain	3692194	823	500	16
86	Lionel Osmin & Cie 2016 La Réserve Petit Manseng (Vin de France)	France	1529584	977	500	11
87	Mitolo 2016 Jester Sangiovese Rosé (McLaren Vale)	Australia	5859052	960	750	20
88	Napa Cellars 2014 Classic Zinfandel (Napa Valley)	US	8747852	855	500	24
89	P.J. Valckenberg 2015 Undone Dry Riesling (Rheinhessen)	Germany	5343806	640	750	10
90	Palencia 2016 Albariño (Ancient Lakes)	US	4214461	266	750	20
91	Passaggio 2014 Blau Vineyards Merlot (Knights Valley)	US	5786045	728	750	55
92	Poggio Alloro 2014 Le Mandorle Riserva  (Vernaccia di San Gimignano)	Italy	4880469	817	750	29
93	Fattoria Sardi 2015 Rosato (Toscana)	Italy	3921501	797	750	19
94	Ferrari-Carano 2014 Siena Red (Sonoma County)	US	9231141	961	750	23
95	Folie à Deux 2015 Pinot Gris (Sonoma Coast)	US	4019443	602	500	18
96	Franciscan 2013 Magnificat Meritage (Napa Valley)	US	4217286	338	500	55
97	Fuchs 2015 Grüner Veltliner (Burgenland)	Austria	5653646	49	750	12
98	Gård 2014 Grand Klasse Reserve Lawrence Vineyards Viognier (Columbia Valley (WA))	US	7724491	219	500	22
99	Henry Fessy 2015  Juliénas	France	6067689	773	500	20
100	Henry Fessy 2015  Régnié	France	6910466	569	750	18
101	Heron Hill 2015 Ingle Vineyard Riesling (Finger Lakes)	US	5190245	900	750	20
102	Serpaia di Endrizzi 2010 Dono Riserva  (Morellino di Scansano)	Italy	3448445	112	750	30
103	Soquel Vineyards 2013 Intreccio Library Selection Red (Napa Valley)	US	4493892	196	500	75
104	Ventosa 2015 Pinot Gris (Finger Lakes)	US	2366879	560	500	18
105	Lamoreaux Landing 2014 Red Oak Vineyard Riesling (Finger Lakes)	US	9086061	305	750	20
106	Lamoreaux Landing 2014 Yellow Dog Vineyard Riesling (Finger Lakes)	US	115058	610	750	20
107	Leyda 2015 Single Vineyard Falaris Hill Chardonnay (Leyda Valley)	Chile	3015156	512	500	18
108	Madonna Alta 2014 Nativo Red (Toscana)	Italy	3084417	223	750	16
109	Marchesi Antinori 2015 Villa Antinori White (Toscana)	Italy	353406	73	750	14
110	Martin Ranch 2014 J.D. Hurley Zinfandel (Santa Clara Valley)	US	6999164	234	750	26
111	Ornellaia 2014 Le Volte Red (Toscana)	Italy	7863830	651	750	30
112	Pardon et Fils 2015 Les Quartelets  (Brouilly)	France	3995612	47	750	23
113	Piña 2013 Wolff Vineyard Cabernet Sauvignon (Yountville)	US	9735849	170	500	85
114	Podere Ciona 2014 Semifonte Red (Toscana)	Italy	5113797	910	500	15
115	Poggioventoso 2015 Poetico White (Toscana)	Italy	8214055	594	500	19
116	Pull 2012 BDX Red (Paso Robles)	US	2674599	178	500	18
117	Pull 2013 Chardonnay (Paso Robles)	US	527450	630	750	18
118	R2 2013 Camp 4 Vineyard Grenache Blanc (Santa Ynez Valley)	US	2668885	396	750	25
119	Rideau 2014 Estate Syrah	US	432041	34	750	44
120	Tenuta Forconi 2013 Toscano Red (Toscana)	Italy	6781876	792	750	80
121	Dopff & Irion 2004 Schoenenbourg Grand Cru Vendanges Tardives Riesling (Alsace)	France	8101419	922	500	80
122	Ceretto 2003 Bricco Rocche Prapó  (Barolo)	Italy	7363140	349	750	70
123	Matrix 2007 Stuhlmuller Vineyard Chardonnay (Alexander Valley)	US	3099541	830	750	36
124	Mauritson 2007 Rockpile Cemetary Vineyard Zinfandel (Rockpile)	US	1222222	392	750	39
125	Silverado 2006 Cabernet Sauvignon (Napa Valley)	US	4050053	564	500	45
126	Le Riche 2003 Cabernet Sauvignon Reserve Cabernet Sauvignon (Stellenbosch)	South Africa	8172572	814	750	45
127	Pierre Sparr 2007 Vendages Tardives Gewurztraminer (Alsace)	France	7024170	48	750	48
128	Pierre Sparr 2008 Alsace One White (Alsace)	France	138317	381	750	13
129	Kuentz-Bas 2008 Pinot Blanc (Alsace)	France	3623789	854	750	17
130	Ceretto 2003 Bricco Rocche Brunate  (Barolo)	Italy	8543827	337	500	70
131	Dopff & Irion 2008 Gentil White (Alsace)	France	2030858	697	750	20
132	Delheim 2001 Grand Reserve Cabernet Sauvignon (Simonsberg-Stellenbosch)	South Africa	4841458	709	500	30
133	Poderi Luigi Einaudi 2003  Barolo	Italy	9068666	341	750	68
134	Clark-Clauden 2007 Cabernet Sauvignon (Napa Valley)	US	9512118	859	750	78
135	Giacomo Ascheri 2001 Sorano  (Barolo)	Italy	689457	105	750	60
136	Lassègue 2003  Saint-Émilion	France	4824797	36	750	50
137	Dopff & Irion 2008 Crustacés White (Alsace)	France	2241369	669	500	10
138	Kuentz-Bas 2007 Cuvée Jerémy Sélection de Grains Nobles Pinot Gris (Alsace)	France	6956960	672	750	112
139	Giacomo Ascheri 2003 Vigna dei Pola  (Barolo)	Italy	2634724	615	500	45
140	Banyan 2007 Riesling (Santa Lucia Highlands)	US	2298470	684	750	17
141	Domaine Zind-Humbrecht 2007 Hunawihr Clos Windsbuhl Pinot Gris (Alsace)	France	1908403	382	750	84
142	Terra Valentine 2013 K Block Cabernet Sauvignon (Spring Mountain District)	US	4331096	403	750	85
143	Testarossa 2013 Guidotti Vineyard Pinot Noir (Santa Lucia Highlands)	US	7930368	379	750	64
144	Vincent Vineyards 2010 Family Reserve Cabernet Sauvignon (Santa Ynez Valley)	US	1147609	674	500	68
145	Vincent Vineyards 2012 Family Reserve Cabernet Sauvignon (Santa Ynez Valley)	US	8556496	31	500	68
146	Weingut Liebfrauenstift 2014 Dry Riesling (Rheinhessen)	Germany	8510605	513	500	16
147	Wrath 2013 Destruction Level Red (Monterey)	US	8265549	326	500	35
148	Herdade Grande 2014 Gerações Colheita Seleccionada Branco White (Alentejano)	Portugal	2412303	28	500	30
149	Albatross Ridge 2012 Estate Reserve Pinot Noir (Carmel Valley)	US	9753520	712	750	55
150	Alta Colina 2012 Old 900 Syrah (Paso Robles)	US	4792555	252	750	46
151	Marques de Griñon 2010 Single Vineyard Estate Bottled Graciano (Dominio de Valdepusa)	Spain	3991875	589	750	50
152	Big Basin 2013 Syrah (Santa Cruz Mountains)	US	5431733	54	500	36
153	Carl Graff 2014 Graacher Himmelreich Spätlese Riesling (Mosel)	Germany	6031314	897	500	14
154	Casa Santa Vitória 2013 Grande Reserva Tinto Red (Alentejano)	Portugal	1694466	386	500	26
155	Castello di Gabbiano 2012 Bellezza Gran Selezione  (Chianti Classico)	Italy	4479738	195	500	38
156	Château Vincens 2012 Malbec (Cahors)	France	7607663	141	500	35
157	Chronic Cellars 2013 Mr. Nibbles Red (Paso Robles)	US	4784591	594	500	35
158	Claiborne & Churchill 2014 Claiborne Vineyard Riesling (Edna Valley)	US	426034	293	750	28
159	Conde de Velázquez 2012 Condesa Real Premium Blend Red (Aconcagua Valley)	Chile	218457	79	750	29
160	Cono Sur 2012 20 Barrels Cabernet Sauvignon (Maipo Valley)	Chile	2697337	987	750	32
161	Domaine Berthoumieu 2013 Charles de Batz Tannat-Cabernet (Madiran)	France	2472011	937	500	25
162	Dracaena 2013 Cabernet Franc (Paso Robles)	US	1951008	72	500	28
163	Duckhorn 2012 Rector Creek Vineyard Merlot (Napa Valley)	US	7324173	836	500	95
164	Dutton-Goldfield 2014 Dutton Ranch Pinot Noir (Russian River Valley)	US	1000275	482	500	44
165	Fritz Haag 2014 Brauneberger Feinherb Riesling (Mosel)	Germany	2140336	43	500	30
166	Fritz Haag 2014 Riesling (Mosel)	Germany	5625519	16	500	22
167	G7 2012 The 7th Generation Gran Reserva Estate Bottled Cabernet Sauvignon (Loncomilla Valley)	Chile	9053571	781	500	20
168	Le Cadeau 2014 Pinot Noir (Willamette Valley)	US	615993	760	750	38
169	Stoneleigh 2008 Sauvignon Blanc (Marlborough)	New Zealand	9993033	832	500	19
170	Tenuta Peter Sölva & Söhne 2007 De Silva Sauvignon (Alto Adige)	Italy	2234552	661	750	25
171	TerraMater 2006 Unusual Cabernet-Shiraz-Zinfandel Red (Maipo Valley)	Chile	4207672	963	500	50
172	Isole e Olena 2005  Chianti Classico	Italy	8871324	421	750	22
173	Kenwood 2005 Jack London Vineyard Syrah (Sonoma Valley)	US	206266	364	750	25
174	La Chablisienne 2006 Les Vénérables Vieilles Vignes  (Chablis)	France	8762181	49	750	27
175	Manzoni 2006 Lucia Highland Vineyard Chardonnay (Santa Lucia Highlands)	US	3594256	614	500	23
176	McIntyre Vineyards 2006 Mission Ranch Pinot Noir (Arroyo Seco)	US	4957770	920	750	36
177	Alamos 2007 Torrontés (Salta)	Argentina	6782958	156	500	12
178	Anaba 2007 Chardonnay (Sonoma Coast)	US	5118968	514	500	35
179	Apaltagua 2007 Envero Gran Reserva Carmenère (Colchagua Valley)	Chile	449385	737	500	15
180	Harrington 2006 Wiley Vineyard Pinot Noir (Anderson Valley)	US	5800896	152	750	40
181	Abbazia Santa Anastasia 2003 Montenero Red (Sicilia)	Italy	2665653	59	500	48
182	Viña Bisquertt 2007 Casa La Joya Reserve Merlot (Colchagua Valley)	Chile	9451334	194	500	11
183	Emiliana 2008 Natura Chardonnay (Casablanca Valley)	Chile	808201	305	500	11
184	Fattoria Alois 2007 Campole Red (Campania)	Italy	198177	442	750	26
185	Aldegheri 2003 Le Pietre Santambrogio Red (Rosso del Veronese)	Italy	9420263	507	500	20
186	Bertrand Ambroise 2006  St.-Romain	France	1340469	539	750	35
187	Carpineto 2003 Riserva  (Vino Nobile di Montepulciano)	Italy	5709496	87	750	35
188	Cesani 2007 Pancole  (Vernaccia di San Gimignano)	Italy	2006572	766	500	18
189	Spier 2014 21 Gables Chenin Blanc (Western Cape)	South Africa	5815214	883	750	23
190	Sequum 2013 Four Soil Mélange Cabernet Sauvignon (Napa Valley)	US	4861661	104	500	60
191	Sierra Starr 2014 Rising Starr Estate Bottled Cabernet Franc (Nevada County)	US	3349151	980	500	28
192	Terlan 2014 Nova Domus Riserva White (Alto Adige)	Italy	5093332	701	750	62
193	Yatir 2011 Syrah (Judean Hills)	Israel	9716409	104	500	50
194	Adega Cooperativa de Borba 2012 Montes Claros Garrafeira Red (Alentejo)	Portugal	2572692	616	750	28
195	J. Lohr 2014 Gesture G-S-M (Paso Robles)	US	1496689	681	750	30
196	J. Lohr 2015 October Night Chardonnay (Arroyo Seco)	US	9952998	949	750	25
197	Courtney Benham 2014 Cabernet Sauvignon (Napa Valley)	US	4862405	743	750	25
198	Del Carlo Winery 2014 Home Ranch Teldeschi Vineyards Century Old Vine Zinfandel (Dry Creek Valley)	US	9576371	172	500	32
199	Delaire Graff 2013 Reserve White (Coastal Region)	South Africa	211214	742	750	40
200	Domaine St Pierre 2014 Red (Côtes du Rhône)	France	5601367	581	750	16
201	Eikendal 2014 Chardonnay (Western Cape)	South Africa	9412673	916	500	20
202	Famille Perrin 2013 Les Christins Red (Vacqueyras)	France	2553444	373	750	32
203	Matarromera 2015 Fermentado en Barrica Verdejo (Rueda)	Spain	9937538	442	750	40
204	MCV 2014 1105 Red (Paso Robles)	US	1802509	941	750	48
205	Mounts 2014 Verah Red (Dry Creek Valley)	US	1506167	171	750	36
206	Or Haganuz 2014 French Blend Red (Galilee)	Israel	235075	363	500	80
207	Podere Scopetone 2012  Brunello di Montalcino	Italy	5954964	279	750	57
208	Quinta de Foz de Arouce 2013 Red (Beira Atlantico)	Portugal	6133162	846	750	20
209	Robert Mondavi 2015 Fumé Blanc (Napa Valley)	US	1666713	575	500	20
210	Samuel Tinon 2015 Megyer Dry Furmint (Tokaj)	Hungary	1838785	857	500	36
211	Sixteen by Twenty 2014 Chardonnay (Sonoma Coast)	US	4595708	520	500	40
212	St. Pauls 2014 Passion Riserva Pinot Bianco (Alto Adige)	Italy	7832516	498	500	40
213	Mendel 2014 Lunta Malbec (Luján de Cuyo)	Argentina	2084530	87	750	22
214	Oldenburg 2013 Chardonnay (Stellenbosch)	South Africa	4230956	984	750	25
215	Oldenburg 2014 Chenin Blanc (Stellenbosch)	South Africa	4584369	575	500	20
216	Wagner 2006 Grace House Pinot Noir (Finger Lakes)	US	3704852	974	500	15
217	Treleaven 2006 Semi-Dry Riesling (Cayuga Lake)	US	7654235	151	500	14
218	Benessere 2005 Costa Del Sol Red (Napa Valley)	US	9430613	709	500	18
219	Bloomer Creek 2006 Gewürztraminer (Finger Lakes)	US	9858323	375	500	16
220	Andean Sky 2007 Bonarda (Mendoza)	Argentina	1833495	349	500	10
221	Silvan Ridge 2006 Reserve Pinot Noir (Willamette Valley)	US	4103590	652	500	28
222	Testarossa 2006 Thompson Vineyard Syrah (Santa Barbara County)	US	8585110	26	500	49
223	Meeker 2004 Kiss Ridge Vineyard Cabernet Sauvignon (Diamond Mountain District)	US	9942889	259	750	85
224	Consorzio Vini Tipici di San Marino NV Moscato (San Marino)	Italy	8098494	349	500	18
225	Dogwood 2005 Cabernet Sauvignon (Mendocino)	US	6308861	933	500	36
226	Domaine du Tariquet 2007 Ugni Blanc-Colombard (Vin de Pays des Côtes de Gascogne)	France	1694686	645	500	9
227	Falcor 2005 Sangiovese (Napa Valley)	US	7051474	970	750	34
228	Hayman & Hill 2007 Reserve Selection Chardonnay (Russian River Valley)	US	324532	835	500	15
229	Hermann J. Wiemer 2002 Blanc de Blanc Chardonnay (Finger Lakes)	US	3508924	439	750	30
230	J. & F. Lurton 2007 Herederos de François Lurton Villafrance de Duero Red (Vino de la Tierra de Castilla y León)	Spain	5965312	685	500	13
231	Finca Las Moras 2007 Reserve Chardonnay (San Juan)	Argentina	8796459	117	750	12
232	Long Flat 2006 Destinations Sauvignon Blanc (Adelaide Hills)	Australia	5240734	984	500	15
233	Work 2004 Reserve Merlot (Sonoma Mountain)	US	1887185	852	750	25
234	Amity 2006 Estate Single Vineyard Pinot Noir (Willamette Valley)	US	5099383	558	500	45
235	Autumn Hill 2007 Petit Verdot-Merlot Red (Monticello)	US	8802904	735	750	18
236	Blue Rock 2005 Estate Cabernet Sauvignon (Alexander Valley)	US	548351	64	750	49
237	Cherry Hill 2006 Papillon Estate Pinot Noir (Willamette Valley)	US	3013165	151	500	22
238	Cloud 9 2006 Seity Zinfandel (Amador County)	US	5866457	434	500	35
239	Cueva de las Manos 2007 Reserve Malbec (Luján de Cuyo)	Argentina	9010581	51	500	15
240	David Fulton 2008 Petite Sirah (St. Helena)	US	2052445	485	500	45
241	Esterlina 2009 Reserva Pinot Noir (Cole Ranch)	US	6504262	451	750	55
242	Goats do Roam Wine Co. 2008 Goat-Roti Syrah-Viognier (Coastal Region)	South Africa	7997400	880	750	20
243	Graham Beck 2007 The William Red (Coastal Region)	South Africa	5969655	691	500	18
244	Hartenberg 2007 Cabernet Sauvignon (Stellenbosch)	South Africa	9600468	417	500	35
245	Vignobles 46N118 2007 Noir 46 Malbec (Cahors)	France	1467203	249	750	13
246	Willamette Valley Vineyards 2009 Estate Pinot Noir (Willamette Valley)	US	5907312	563	500	40
247	Algodon 2008 Estate Blend Gran Reserva Red	Argentina	4003731	694	750	37
248	Beaver Creek 2008 Fairytale Red (Napa Valley)	US	7412992	867	500	39
249	Byron 2009 Monument Pinot Noir (Santa Maria Valley)	US	702356	321	500	60
250	Jardin 2007 Syrah (Stellenbosch)	South Africa	8740153	713	750	19
251	Jardin 2009 Nine Yards Chardonnay (Stellenbosch)	South Africa	1934891	353	750	40
252	Kaiken 2008 Corte Malbec-Bonarda-Petit Verdot Red (Mendoza)	Argentina	7040714	938	750	14
253	Lungarotti 2007 Torre di Giano Vigna il Pino White (Torgiano)	Italy	137874	153	750	40
254	Marchesi Fumanelli 2005 Terso White (Veneto)	Italy	8516669	450	750	36
255	Mariell 2009 Blaufränkisch (Leithaberg)	Austria	5329226	899	500	17
256	Livio Felluga 2009 Friulano (Colli Orientali del Friuli)	Italy	7918202	292	500	25
257	My Big Fat Greek Wine 2010 Assyrtico (Santorini)	Greece	2151511	664	750	15
258	Nals Margreid 2010 Sirmian Pinot Bianco (Alto Adige)	Italy	8653149	530	500	26
259	O. Fournier 2007 B Crux Red (Uco Valley)	Argentina	2070013	690	500	19
260	Pico Maccario 2010 Estrosa White (Monferrato)	Italy	3701771	767	500	13
261	Sottano 2009 Reserva de Familia Cabernet Sauvignon (Mendoza)	Argentina	1127876	29	750	30
262	St. Francis 2009 Old Vines Zinfandel (Sonoma County)	US	8314928	819	500	20
263	Trailhead 2010 Cabernet Sauvignon (Napa Valley)	US	7640625	85	750	30
264	Erath 2009 Bishop Creek Pinot Noir	US	6910929	245	750	50
265	Franz Haas 2009 Sauvignon (Alto Adige)	Italy	1854523	640	750	52
266	Forstreiter 2012 Schiefer Reserve Grüner Veltliner (Kremstal)	Austria	5609213	464	750	24
267	Cambria 2011 Bench Break Vineyard Pinot Noir (Santa Maria Valley)	US	4076223	140	750	34
268	I Giusti e Zanza 2009 Dulcamara Red (Toscana)	Italy	1802890	829	750	41
269	J. Christopher 2011 Bella Vida Vineyard Unfiltered Pinot Noir (Dundee Hills)	US	436419	37	750	52
270	Viña Cobos 2011 Marchiori Vineyard Block C2 Malbec (Perdriel)	Argentina	4402383	471	750	215
271	Talley 2011 Rincon Vineyard Pinot Noir (Arroyo Grande Valley)	US	5073803	628	500	60
272	Acústic 2010 Braó Vinyes Velles Carignan-Grenache (Montsant)	Spain	6207036	981	500	40
273	Parallel 2010 Fortune Teller Cabernet Sauvignon (Napa Valley)	US	7069340	390	750	125
274	Domaine Daniel Dugois 2006 Vin Jaune Savagnin (Arbois)	France	4970552	243	750	45
275	Finca Sophenia 2011 Synthesis Malbec (Tupungato)	Argentina	1992012	76	500	30
276	Treana 2008 Treana Red Cabernet Sauvignon-Syrah (Paso Robles)	US	4731531	934	750	35
277	Ventisquero 2008 Grey [Glacier] Single Block Trinidad Vineyard Cabernet Sauvignon (Maipo Valley)	Chile	8126473	323	750	20
278	Aquinas 2008 Cabernet Sauvignon (Napa Valley)	US	4598735	584	500	15
279	Arboleda 2009 Cabernet Sauvignon (Aconcagua Valley)	Chile	5807702	371	750	19
280	Benessere 2007 Estate Sangiovese (Napa Valley)	US	3761804	826	750	28
281	Buried Cane 2009 Whiteline No Oak Chardonnay (Columbia Valley (WA))	US	3641838	949	500	14
282	Cascina Adelaide 2005 4 Vigne  (Barolo)	Italy	4319762	926	750	56
283	Claudia Springs 2007 Zinfandel (Mendocino County)	US	95871	24	500	24
284	Cramele Recas 2009 Chardonnay (Recas)	Romania	9510879	582	500	7
285	Domaine Bertagna 2009 Les Dames Huguettes  (Côte de Nuits-Villages)	France	5955422	438	750	30
286	Domaine Sigalas 2010 Asirtiko Athiri White (Santorini)	Greece	9937903	582	750	18
287	Socré 2006 Nebbiolo (Langhe)	Italy	8638366	881	500	20
288	Boffa 2006 Nebbiolo (Langhe)	Italy	5994539	723	500	18
289	Mount Veeder 2008 Cabernet Sauvignon (Napa Valley)	US	3629338	538	500	40
290	Robert Mondavi 2008 Cabernet Sauvignon (Napa Valley)	US	5299172	466	500	28
291	Bellussi NV Extra Dry  (Prosecco di Valdobbiadene)	Italy	7150744	401	750	15
292	Aresti 2007 Reserva Merlot (Curicó Valley)	Chile	4596449	1	750	18
293	Paladin 2007 Millesimato Brut Prosecco (Veneto)	Italy	9768769	327	750	20
294	Perlage 2008 Col di Manza Extra Dry Millesimato  (Prosecco di Valdobbiadene)	Italy	9449414	276	750	22
295	Sant Eurosia 2007 Brut  (Prosecco di Valdobbiadene)	Italy	8806947	579	500	16
296	Sant Eurosia 2007 Millesimato Dry  (Prosecco di Valdobbiadene)	Italy	4175958	598	500	18
297	J. & F. Lurton 2006 Gran Araucano Cabernet Sauvignon (Colchagua Valley)	Chile	9419287	71	500	35
298	Lucas Vineyards 2007 Vignoles (Finger Lakes)	US	8301200	543	750	11
299	Marsuret NV Extra Dry  (Prosecco di Valdobbiadene)	Italy	8208362	572	500	15
300	De Martino 2007 Legado Reserva Chardonnay (Limarí Valley)	Chile	3888343	765	750	18
301	Beringer 2007 Alluvium Blanc White (Knights Valley)	US	3164070	874	500	16
302	Brutocao 2006 Reserve Zinfandel (Mendocino)	US	517368	29	750	34
303	Cono Sur 2008 Visión Gewürztraminer (Casablanca Valley)	Chile	8242084	467	500	15
304	Sommariva NV Palazzo Rosso Brut  (Prosecco di Conegliano)	Italy	5657884	278	750	19
305	Spagnol NV Col del Sas Extra Dry  (Prosecco di Valdobbiadene)	Italy	9341262	606	750	18
306	Jacquart NV Mosaïque Rosé Brut  (Champagne)	France	361816	918	750	42
307	Koyle 2015 Costa Pinot Noir (Colchagua Costa)	Chile	4162069	782	750	35
308	Château Notre Dame du Quatourze 2015 Rosé (Languedoc)	France	212244	252	750	16
309	Mémoires 2015 Rosé (Coteaux Varois en Provence)	France	6557310	581	500	11
310	Cavas Hill NV 1887 Rosado Sparkling (Cava)	Spain	7801715	471	750	13
\.


--
-- Name: winelist_wine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.winelist_wine_id_seq', 310, true);


--
-- Name: winelist winelist_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.winelist
    ADD CONSTRAINT winelist_code_key UNIQUE (code);


--
-- Name: winelist winelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.winelist
    ADD CONSTRAINT winelist_pkey PRIMARY KEY (wine_id);


--
-- Name: winelist winelist_title_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.winelist
    ADD CONSTRAINT winelist_title_key UNIQUE (title);


--
-- PostgreSQL database dump complete
--

